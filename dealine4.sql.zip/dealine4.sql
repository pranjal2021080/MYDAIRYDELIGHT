USE mydairydelight;

SELECT p_name 
FROM product
WHERE price > '100';

SELECT inventory_id
FROM coldStores
WHERE storeCapacity > '1000';

SELECT *
FROM customer
WHERE customerType = 'normal';

SELECT special_offer, cart_id
FROM cart
WHERE total_cost > '400';




